@echo off
setlocal

cd /d "%~dp0"

set "STATA_EXE="

if exist "C:\Program Files\Stata18\StataMP-64.exe" set "STATA_EXE=C:\Program Files\Stata18\StataMP-64.exe"
if exist "C:\Program Files\Stata18\StataSE-64.exe" set "STATA_EXE=C:\Program Files\Stata18\StataSE-64.exe"
if exist "C:\Program Files\Stata18\StataBE-64.exe" set "STATA_EXE=C:\Program Files\Stata18\StataBE-64.exe"
if exist "C:\Program Files\Stata17\StataMP-64.exe" set "STATA_EXE=C:\Program Files\Stata17\StataMP-64.exe"
if exist "C:\Program Files\Stata17\StataSE-64.exe" set "STATA_EXE=C:\Program Files\Stata17\StataSE-64.exe"
if exist "C:\Program Files\Stata17\StataBE-64.exe" set "STATA_EXE=C:\Program Files\Stata17\StataBE-64.exe"
if exist "C:\Program Files\Stata16\StataMP-64.exe" set "STATA_EXE=C:\Program Files\Stata16\StataMP-64.exe"
if exist "C:\Program Files\Stata16\StataSE-64.exe" set "STATA_EXE=C:\Program Files\Stata16\StataSE-64.exe"

if "%STATA_EXE%"=="" (
    echo Stata executable was not found in common install paths.
    echo Please edit this BAT file and set STATA_EXE to your Stata executable path.
    exit /b 1
)

echo Using Stata: %STATA_EXE%
"%STATA_EXE%" /e do run_panel_sdm.do

if exist sdm_run_log.log (
    python parse_sdm_log.py
    echo Done. See results\sdm_effects_extracted.txt
) else (
    echo sdm_run_log.log was not generated. Please check Stata.
    exit /b 1
)

endlocal
