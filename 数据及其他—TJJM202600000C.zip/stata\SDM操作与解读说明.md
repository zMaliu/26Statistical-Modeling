# Stata SDM操作与解读说明

## 运行顺序

1. 在 Stata 中把工作目录切换到本文件夹：`cd "E:/文档/文档/统计建模/26Statistical-Modeling/stata"`。
2. 运行：`do run_panel_sdm.do`。
3. 重点查看每次 `xsmle` 输出中 `Effects` 或 `Direct / Indirect / Total` 部分。
4. 运行日志会保存为 `sdm_run_log.smcl`，模型结果会保存到 `results/` 文件夹。

## 三类空间矩阵

- `w_inverse_distance_stata.csv`：主模型，地理反距离矩阵。
- `w_knn4_distance_stata.csv`：稳健性检验，4近邻矩阵。
- `w_geo_economic_stata.csv`：稳健性检验，地理距离与经济距离嵌套矩阵。

## 结果解读优先级

SDM 不建议直接解读原始回归表中的 `ai` 或空间滞后项系数。论文中应优先汇报效应分解：

- `Direct Effect`：本市 AI/数字产业对本市协调发展参照指标的影响。
- `Indirect Effect`：本市 AI/数字产业对邻近城市的空间溢出影响。
- `Total Effect`：直接效应与间接效应之和。

## 三种论文叙事预案

- 如果 `Indirect(ai)` 显著为正：说明存在正向空间溢出，可写“核心城市 AI/数字产业通过技术扩散、产业链协作带动周边城市”。
- 如果 `Indirect(ai)` 显著为负：说明存在虹吸或极化，可写“AI/数字产业集聚强化核心城市吸附能力，短期可能扩大区域差异”。
- 如果 `Indirect(ai)` 不显著：说明尚未形成稳定外溢，可写“广东 AI/数字产业仍呈点状集聚，跨市扩散机制不足”。

## 注意

当前 `coord` 是协调发展参照指标，`ai` 是全域 AI/数字产业代理指数。若后续获得更完整的年报文本 AI 指数，应替换 `ai` 后重跑全流程。
