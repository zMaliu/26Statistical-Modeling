﻿# Panel SDM 估计结果解读

说明：本结果由开源 Python 空间面板程序生成，用于估计双向固定效应 Panel SDM，并分解直接效应、间接效应与总效应。

## 模型概况

| matrix | rho | nobs | note |
|---|---:|---:|---|
| inverse_distance | -0.1028 | 126 | Two-way FE Panel SDM; variables standardized before estimation |
| knn4 | 0.0489 | 126 | Two-way FE Panel SDM; variables standardized before estimation |
| geo_economic | 0.0428 | 126 | Two-way FE Panel SDM; variables standardized before estimation |

## 主变量AI的效应分解

| effect_type | estimate | p_value |
|---|---:|---:|
| direct | 0.0204 | 0.7030 |
| indirect | -0.8468 | 0.0365 |
| total | -0.8264 | 0.0632 |

## 叙事判断

AI 间接效应显著为负，可解释为空间虹吸或阶段性空间极化：核心城市 AI/数字产业可能在短期内吸附周边资源，扩大区域发展差异。
