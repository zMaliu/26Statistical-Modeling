from __future__ import annotations

from pathlib import Path

import pandas as pd


BASE = Path(__file__).resolve().parent
REQUIRED = [
    "panel_sdm_stata.csv",
    "panel_sdm_stata.dta",
    "city_id_map.csv",
    "w_inverse_distance_stata.csv",
    "w_knn4_distance_stata.csv",
    "w_geo_economic_stata.csv",
    "run_panel_sdm.do",
    "run_stata_sdm.ps1",
    "run_stata_sdm.bat",
    "parse_sdm_log.py",
]


def check_matrix(path: Path, n: int) -> None:
    df = pd.read_csv(path)
    assert df.shape == (n, n + 1), f"{path.name} shape {df.shape}, expected {(n, n + 1)}"
    assert "city_id" in df.columns, f"{path.name} missing city_id"
    row_sums = df.drop(columns=["city_id"]).sum(axis=1)
    if not row_sums.round(8).eq(1.0).all():
        raise AssertionError(f"{path.name} row sums are not all 1")
    diagonal = [df.loc[i, f"w{i+1}"] for i in range(n)]
    if any(abs(x) > 1e-10 for x in diagonal):
        raise AssertionError(f"{path.name} diagonal is not zero")


def main() -> None:
    missing = [name for name in REQUIRED if not (BASE / name).exists()]
    if missing:
        raise FileNotFoundError(f"Missing files: {missing}")

    panel = pd.read_csv(BASE / "panel_sdm_stata.csv")
    city_map = pd.read_csv(BASE / "city_id_map.csv")
    assert panel.shape[0] == 126, f"Panel rows should be 126, got {panel.shape[0]}"
    assert panel["city_id"].nunique() == 21, "Panel should contain 21 cities"
    assert panel["year"].nunique() == 6, "Panel should contain 6 years"
    assert not panel.duplicated(["city_id", "year"]).any(), "Duplicated city-year rows found"
    assert city_map.shape[0] == 21, "city_id_map should contain 21 rows"

    for name in ["w_inverse_distance_stata.csv", "w_knn4_distance_stata.csv", "w_geo_economic_stata.csv"]:
        check_matrix(BASE / name, 21)

    print("Stata package check passed.")
    print(f"Panel rows: {panel.shape[0]}; cities: {panel['city_id'].nunique()}; years: {panel['year'].nunique()}")


if __name__ == "__main__":
    main()

