from __future__ import annotations

import re
from pathlib import Path


BASE = Path(__file__).resolve().parent
LOG_PATH = BASE / "sdm_run_log.log"
OUT_PATH = BASE / "results" / "sdm_effects_extracted.txt"


def extract_effect_blocks(text: str) -> list[str]:
    """Extract human-readable effect decomposition blocks from xsmle logs.

    xsmle versions print effects slightly differently.  This parser therefore
    keeps a broad window around lines containing Direct/Indirect/Total.
    """
    lines = text.splitlines()
    hit_indices = [
        i
        for i, line in enumerate(lines)
        if re.search(r"\b(Direct|Indirect|Total)\b", line, flags=re.IGNORECASE)
    ]
    blocks: list[str] = []
    seen: set[tuple[int, int]] = set()
    for idx in hit_indices:
        start = max(0, idx - 8)
        end = min(len(lines), idx + 18)
        key = (start, end)
        if key in seen:
            continue
        seen.add(key)
        blocks.append("\n".join(lines[start:end]))
    return blocks


def main() -> None:
    if not LOG_PATH.exists():
        raise FileNotFoundError(f"Missing Stata log: {LOG_PATH}")
    text = LOG_PATH.read_text(encoding="utf-8", errors="ignore")
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    blocks = extract_effect_blocks(text)
    if blocks:
        content = "\n\n" + "=" * 80 + "\n\n"
        content = content.join(blocks)
    else:
        content = (
            "未在日志中自动识别到 Direct / Indirect / Total 效应分解块。\n"
            "请手动搜索 sdm_run_log.log 中的 Effects、Direct、Indirect 或 Total。\n"
        )

    OUT_PATH.write_text(content, encoding="utf-8")
    print(f"Wrote {OUT_PATH}")


if __name__ == "__main__":
    main()

