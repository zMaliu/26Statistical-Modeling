param(
    [string]$StataPath = ""
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

function Find-StataExecutable {
    param([string]$UserPath)

    if ($UserPath -and (Test-Path -LiteralPath $UserPath)) {
        return (Resolve-Path -LiteralPath $UserPath).Path
    }

    $commandNames = @(
        "StataMP-64.exe",
        "StataSE-64.exe",
        "StataBE-64.exe",
        "StataIC-64.exe",
        "Stata-64.exe",
        "StataMP.exe",
        "StataSE.exe",
        "StataBE.exe",
        "StataIC.exe",
        "Stata.exe"
    )

    foreach ($name in $commandNames) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue
        if ($cmd) {
            return $cmd.Source
        }
    }

    $roots = @(
        "C:\Program Files\Stata18",
        "C:\Program Files\Stata17",
        "C:\Program Files\Stata16",
        "C:\Program Files\Stata15",
        "C:\Program Files (x86)\Stata18",
        "C:\Program Files (x86)\Stata17",
        "C:\Program Files (x86)\Stata16",
        "D:\Program Files\Stata18",
        "D:\Program Files\Stata17",
        "D:\Program Files\Stata16"
    )

    foreach ($root in $roots) {
        if (Test-Path -LiteralPath $root) {
            foreach ($name in $commandNames) {
                $candidate = Join-Path $root $name
                if (Test-Path -LiteralPath $candidate) {
                    return (Resolve-Path -LiteralPath $candidate).Path
                }
            }
        }
    }

    return ""
}

$stataExe = Find-StataExecutable -UserPath $StataPath
if (-not $stataExe) {
    Write-Host "Stata executable was not found."
    Write-Host "Please specify the executable path explicitly, for example:"
    Write-Host ".\run_stata_sdm.ps1 -StataPath `"C:\Program Files\Stata18\StataMP-64.exe`""
    exit 1
}

Write-Host "Using Stata: $stataExe"
Write-Host "Working directory: $ScriptDir"

$logPath = Join-Path $ScriptDir "sdm_run_log.log"
if (Test-Path -LiteralPath $logPath) {
    Remove-Item -LiteralPath $logPath -Force
}

$args = @("/e", "do", "run_panel_sdm.do")
$process = Start-Process -FilePath $stataExe -ArgumentList $args -WorkingDirectory $ScriptDir -Wait -PassThru -WindowStyle Hidden
Write-Host "Stata exit code: $($process.ExitCode)"

if (Test-Path -LiteralPath $logPath) {
    Write-Host "Log generated: $logPath"
    python parse_sdm_log.py
} else {
    Write-Host "sdm_run_log.log was not found. Please check whether Stata started successfully."
    exit 1
}
